console.log(require("dotenv").config())
//this will allow us to pull params from .env file
const express = require('express')
const app = express()
app.use(express.json())
//This middleware will allow us to pull req.body.<params>
const port = process.env.TOKEN_SERVER_PORT 
//get the port number from .env file
app.listen(port, () => { 
console.log(`Authorization Server running on ${port}...`)
})

const bcrypt = require ('bcrypt') 
var users = []
var i=1
const fs = require('fs')

// REGISTER A USER
app.post ("/createUser",async(req,res) => {
    try{    
        const user = req.body.name
        const hashedPassword = await bcrypt.hash(req.body.password, 10)

        
        var data=fs.readFileSync('Json files/users.json')
        data=data.toString()
        if(data===''){
            users=[]
        }
        else{
            users=JSON.parse(data)
        }
        var i=users.length
        
        var CRM="CRM"+((i%4)+1)
        users.push ({user: user, password: hashedPassword, CRM:CRM})
        SignupDetails();
        res.status(201).send(users)
        console.log(users)
        }
    catch(e){
            console.log(e)
        }
})

function SignupDetails(){
        const jsonString = JSON.stringify(users)
        fs.writeFile('Json files/users.json', jsonString, err => {
                if (err) {
                    console.log('Error writing file', err)
                } else {
                    console.log('Successfully wrote file')
                }
            })
    }

const jwt = require("jsonwebtoken")
const { join } = require("path")
//AUTHENTICATE LOGIN AND RETURN JWT TOKEN

app.post("/login", async (req,res) => {
users=fs.readFileSync('Json files/users.json')
users=users.toString()
users=JSON.parse(users)

const user = users.find( (c) => {
    if(c.user == req.body.name)
    return true
    })
//check to see if the user exists in the list of registered users
if (!user) res.status(404).send ("User does not exist!")
//if user does not exist, send a 400 response
if (await bcrypt.compare(req.body.password, user.password)) {
const accessToken = generateAccessToken ({user: req.body.name})
const refreshToken = generateRefreshToken ({user: req.body.name})
res.json ({accessToken: accessToken, refreshToken: refreshToken})
} 
else {
res.status(401).send("Password Incorrect!")
}
})
//CRM LOGIN 
app.post("/custLogin" ,(req,res) => {
var crm=[]   

crm=fs.readFileSync('Json files/CRM.json')
crm=crm.toString()
crm=JSON.parse(crm)

const crmList=crm.find((c)=>{
        if(c.CRM==req.body.name && c.password==req.body.password)
            return true
        })

    if (!crmList) res.status(404).send ("User does not exist!")

    if(crmList){
    const accessToken = generateAccessToken ({user: req.body.name})
    const refreshToken = generateRefreshToken ({user: req.body.name})
    res.json ({accessToken: accessToken, refreshToken: refreshToken})
    }
    else {
        res.status(401).send("Password Incorrect!")
    }
})
//BM LOGIN
app.post("/bmLogin" ,(req,res) => {  
            
        const BM=function(){
            if("BM"==req.body.name && "BM@123"==req.body.password)
                return true
            }
    
        if (!BM) res.status(404).send ("User does not exist!")
    
        if(BM){
        const accessToken = generateAccessToken ({user: req.body.name})
        const refreshToken = generateRefreshToken ({user: req.body.name})
        res.json ({accessToken: accessToken, refreshToken: refreshToken})
        }
        else {
            res.status(401).send("Password Incorrect!")
        }
    })

// accessTokens
function generateAccessToken(user) {
    console.log(user)
    return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, {expiresIn: "60m"}) 
    }
    // refreshTokens
    let refreshTokens = []
    function generateRefreshToken(user) {
    const refreshToken = jwt.sign(user, process.env.REFRESH_TOKEN_SECRET, {expiresIn: "65m"})
    refreshTokens.push(refreshToken)
    return refreshToken
    }

    //REFRESH TOKEN API
app.post("/refreshToken", (req,res) => {
    if (!refreshTokens.includes(req.body.token)) res.status(400).send("Refresh Token Invalid")
    refreshTokens = refreshTokens.filter( (c) => c != req.body.token)
    //remove the old refreshToken from the refreshTokens list
    const accessToken = generateAccessToken ({user: req.body.name})
    const refreshToken = generateRefreshToken ({user: req.body.name})
    //generate new accessToken and refreshTokens
    res.json ({accessToken: accessToken, refreshToken: refreshToken})
    })
 
    app.delete("/logout", (req,res)=>{
    refreshTokens = refreshTokens.filter( (c) => c != req.body.token)
    //remove the old refreshToken from the refreshTokens list
    res.status(204).send("Logged out!")
    })