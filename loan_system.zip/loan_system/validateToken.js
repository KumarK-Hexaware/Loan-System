require("dotenv").config()
const express = require("express")
const app = express()
app.use (express.json())
const jwt = require("jsonwebtoken")
const port = process.env.PORT
//We will run this server on a different port i.e. port 5000


//Variables of APIs
app.listen(port,()=> {
console.log(`Validation server running on ${port}...`)
})
app.get("/posts",validateToken, (req, res)=>{
console.log("Token is valid")
console.log(req.user.user)
res.send(`${req.user.user} successfully accessed post`)
})

var newLoan=[]
//APPLY LOAN API
const fs = require('fs')


app.post("/applyLoan",validateToken, (req, res)=>{

const loanAmt= req.body.loanAmount
const loanStatusCRM= "unaccepted"
const loanStatusBM= "unaccepted"
//const loanee = req.body.loanee

var dt=fs.readFileSync('Json files/loanList.json')
dt=dt.toString()
if(dt===''){
    newLoan=[]
}
else{
    newLoan=JSON.parse(dt)
}
//console.log(type(req.user.user))
newLoan.push({
    loanee:req.user.user,
    loanStatusCRM:loanStatusCRM,
    loanStatusBM:loanStatusBM,
    loanAmt:loanAmt

})

const jsonString = JSON.stringify(newLoan)
console.log(jsonString)
        fs.writeFile('Json files/loanList.json', jsonString, err => {
                if (err) {
                    console.log('Error writing file', err)
                } else {
                    console.log('Successfully wrote file')
                }
            })
res.status(200).send(newLoan)
})

//SHOW LOAN LIST    

app.get("/loanList",validateToken, (req,res)=>{
    var user=req.user.user
    var result=[]
    dt=fs.readFileSync('Json files/loanList.json')
    dt=dt.toString()
    dt=JSON.parse(dt)
    for(var i=0;i<dt.length;i++) {
        if(dt[i].loanee==user){
            result.push(dt[i])
        }
    }
    res.send(result)
})

//LOAN STATUS UPDATE BY CRM

app.post("/loanStatusUpdate",validateToken,(req,res)=>{
        var CRM=req.user.user
        var user=[]
        var dt=[]
        dt=fs.readFileSync('Json files/users.json')
        dt=dt.toString()
        dt=JSON.parse(dt)
        //console.log(typeof dt)
        //console.log(CRM)
        var element
        for(var i=0;i<dt.length;i++) {
             element=dt[i];
            if(element.CRM==CRM){
                user.push(element.user);
            }
        };
        console.log(user)
       // res.send(user)
        var data=fs.readFileSync('Json files/loanList.json')
        data=data.toString()
        data=JSON.parse(data)
        for(var i=0;i<user.length;i++){
            for(var j=0;j<data.length;j++){
                //element=dt[j];
                if(user[i]==data[j].loanee){
                    // res.status(201).send(dt[j])
                    // res.status(201).send('please update status')
                    if(data[j].loanAmt>=10000 && data[j].loanAmt<1000000){
                    data[j].loanStatus=req.body.status
                    }
                    else{
                    data[j].loanStatus='rejected';   
                    }
                    console.log(data)
                    
                }
            }
        }
        UpdateLoanList(data)
})
function UpdateLoanList(dt){
    const jsonString = JSON.stringify(dt)
        fs.writeFile('Json files/loanList.json', jsonString, err => {
                if (err) {
                    console.log('Error writing file', err)
                } else {
                    console.log('Successfully wrote file')
                }
            })
}

//LOAN REQUEST LISTS CRM
app.get('/loanRequests',validateToken,(req,res)=>{
    var CRM=req.user.user
        var user=[]
        var dt=[]
        var result=[]
        dt=fs.readFileSync('Json files/users.json')
        dt=dt.toString()
        dt=JSON.parse(dt)
        var element
        for(var i=0;i<dt.length;i++) {
             element=dt[i];
            if(element.CRM==CRM){
                user.push(element.user);
            }
        };
        var data=fs.readFileSync('Json files/loanList.json')
        data=data.toString()
        data=JSON.parse(data)
        for(var i=0;i<user.length;i++){
            for(var j=0;j<data.length;j++){
                if(user[i]==data[j].loanee){
                   result.push(data[j])
                }
            }
        }
    res.send(result)
})
//LOAN STATUS UPDATE BM
app.post('/loanUpdateBM',validateToken,(req,res)=>{
    var data=fs.readFileSync('Json files/loanList.json')
        data=data.toString()
        data=JSON.parse(data)
        for(var j=0;j<data.length;j++){
            if(data[j].loanStatusCRM=='accepted'){
                data[j].loanStatusBM='accepted';
            }
        }
        UpdateLoanList(data)
        res.send(data)
})
//ALL LOAN LIST BM
app.get('/loanListAll',validateToken,(req,res)=>{
    dt=fs.readFileSync('Json files/loanList.json')
    res.send(dt)
})
//VALIDATION FUNCTION
function validateToken(req, res, next) {
    //get token from request header
    const authHeader = req.headers["authorization"]
    const token = authHeader.split(" ")[1]
    //the request header contains the token "Bearer <token>", split the string and use the second value in the split array.
    if (token == null) res.sendStatus(400).send("Token not present")
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) { 
     res.status(403).send("Token invalid")
     }
     else {
     req.user = user
     next() //proceed to the next action in the calling function
     }
    }) //end of jwt.verify()
    } //end of function