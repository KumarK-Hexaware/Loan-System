const EventEmitterClass=require('events')
const emitter=new EventEmitterClass()

//event listener
emitter.on('NewEvent',(arg)=>{
  console.log(arg)  
})

// event creation
emitter.emit('NewEvent',{message:'successfully passed the event message'})